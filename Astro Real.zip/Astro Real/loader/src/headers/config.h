#pragma once

#define HTTP_SERVER "176.65.148.198"
#define HTTP_PORT 80

#define TFTP_SERVER "176.65.148.198"
